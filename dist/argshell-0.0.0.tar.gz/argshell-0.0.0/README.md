# argshell

# **W.I.P.**
Integrates the argparse and cmd modules.

## ~~Installation~~

~~Install with:~~

~~<pre>
pip install argshell
</pre>~~



## ~~Usage~~

<pre>

</pre>
